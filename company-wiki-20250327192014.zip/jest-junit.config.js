module.exports = {
  outputDirectory: './test-results',
  outputName: 'junit.xml',
  classNameTemplate: '{classname}',
  titleTemplate: '{title}',
  ancestorSeparator: ' › ',
  usePathForSuiteName: 'true'
};