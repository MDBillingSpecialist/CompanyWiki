(()=>{var e={};e.id=740,e.ids=[740],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1017:e=>{"use strict";e.exports=require("path")},7310:e=>{"use strict";e.exports=require("url")},6786:(e,r,t)=>{"use strict";t.r(r),t.d(r,{GlobalError:()=>a.a,__next_app__:()=>m,originalPathname:()=>p,pages:()=>l,routeModule:()=>u,tree:()=>c});var s=t(482),i=t(9108),n=t(2563),a=t.n(n),o=t(8300),d={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(d[e]=()=>o[e]);t.d(r,d);let c=["",{children:["wiki",{children:["sop",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,6299)),"/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/sop/page.tsx"]}]},{}]},{metadata:{icon:[async e=>(await Promise.resolve().then(t.bind(t,3881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(t.bind(t,1342)),"/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,9361,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(t.bind(t,3881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],l=["/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/sop/page.tsx"],p="/wiki/sop/page",m={require:t,loadChunk:()=>Promise.resolve()},u=new s.AppPageRouteModule({definition:{kind:i.x.APP_PAGE,page:"/wiki/sop/page",pathname:"/wiki/sop",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},8101:(e,r,t)=>{Promise.resolve().then(t.bind(t,1254))},1254:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>n});var s=t(2295);t(3729);var i=t(9416);function n(){let e=`
# Standard Operating Procedures

## Overview

Standard Operating Procedures (SOPs) are documented, step-by-step instructions that describe how to perform a routine activity. SOPs help maintain quality control, ensure compliance with industry regulations, and reduce miscommunication.

This section contains our organization's official SOPs across different departments and functions.

## Engineering SOPs

These procedures govern our software development, deployment, and maintenance processes.

- [Deployment Process](/wiki/sop/engineering/deployment)
- [Code Review Standards](/wiki/sop/engineering/code-review)
- [Incident Management](/wiki/sop/engineering/incident-management)
- [Testing Protocols](/wiki/sop/engineering/testing-protocols)
- [Database Management](/wiki/sop/engineering/database-management)

## Compliance SOPs

These procedures ensure we maintain regulatory compliance in all operations.

- [Incident Response](/wiki/sop/compliance/incident-response)
- [Audit Procedures](/wiki/sop/compliance/audit-procedures)
- [Risk Assessment](/wiki/sop/compliance/risk-assessment)
- [Security Monitoring](/wiki/sop/compliance/security-monitoring)
- [Training Requirements](/wiki/sop/compliance/training-requirements)

## Creating and Updating SOPs

All SOPs should follow our standard format:

1. **Title and ID**: Clear identification of the procedure
2. **Purpose**: Why the procedure exists
3. **Scope**: What the procedure covers (and doesn't cover)
4. **Responsibilities**: Who performs each step
5. **Procedure**: Step-by-step instructions
6. **References**: Related documents, tools, or regulations
7. **Definitions**: Terminology used in the procedure
8. **Revision History**: Record of changes

To propose a new SOP or update an existing one, please contact the relevant department head or the Compliance Officer.
`,r=(0,s.jsxs)("div",{className:"prose prose-slate dark:prose-invert max-w-none",children:[(0,s.jsxs)("div",{className:"mb-8",children:[s.jsx("h1",{className:"text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white mb-3",children:"Standard Operating Procedures"}),s.jsx("p",{className:"text-xl text-gray-500 dark:text-gray-400",children:"Company-wide standard operating procedures and best practices"}),s.jsx("div",{className:"text-sm text-gray-500 dark:text-gray-400 mt-2",children:"Last updated: March 13, 2025"}),s.jsx("div",{className:"flex flex-wrap gap-2 mt-4",children:["sop","procedures","standards"].map(e=>s.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100",children:e},e))})]}),s.jsx("div",{className:"mdx-content",dangerouslySetInnerHTML:{__html:e}})]});return s.jsx(i.q,{children:s.jsx("article",{className:"prose prose-slate dark:prose-invert max-w-none",children:r})})}},9416:(e,r,t)=>{"use strict";t.d(r,{q:()=>o});var s=t(2295);t(3729);var i=t(7385),n=t(3247),a=t(3846);let o=({children:e})=>(0,s.jsxs)("div",{className:"flex h-screen bg-gray-50 dark:bg-gray-950",children:[s.jsx(i.Sidebar,{}),(0,s.jsxs)("div",{className:"flex-1 h-screen flex flex-col overflow-auto",children:[s.jsx("div",{className:"bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800",children:(0,s.jsxs)("div",{className:"flex flex-col md:flex-row md:items-center md:justify-between px-4 py-3",children:[s.jsx(n.Breadcrumb,{}),s.jsx("div",{className:"mt-3 md:mt-0",children:s.jsx(a.SearchBar,{})})]})}),s.jsx("main",{className:"flex-1 overflow-auto p-6",children:s.jsx("div",{className:"max-w-4xl mx-auto",children:e})}),s.jsx("footer",{className:"py-4 px-6 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900",children:(0,s.jsxs)("div",{className:"text-center text-sm text-gray-500 dark:text-gray-400",children:["\xa9 ",new Date().getFullYear().toString()," Company Wiki • HIPAA Compliant"]})})]})]})},6299:(e,r,t)=>{"use strict";t.r(r),t.d(r,{$$typeof:()=>n,__esModule:()=>i,default:()=>a});let s=(0,t(6843).createProxy)(String.raw`/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/sop/page.tsx`),{__esModule:i,$$typeof:n}=s,a=s.default}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[638,883,754,796],()=>t(6786));module.exports=s})();