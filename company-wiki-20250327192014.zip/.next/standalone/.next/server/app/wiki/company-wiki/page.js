(()=>{var e={};e.id=387,e.ids=[387],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1017:e=>{"use strict";e.exports=require("path")},7310:e=>{"use strict";e.exports=require("url")},444:(e,i,t)=>{"use strict";t.r(i),t.d(i,{GlobalError:()=>o.a,__next_app__:()=>p,originalPathname:()=>m,pages:()=>d,routeModule:()=>u,tree:()=>l});var a=t(482),r=t(9108),n=t(2563),o=t.n(n),s=t(8300),c={};for(let e in s)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(c[e]=()=>s[e]);t.d(i,c);let l=["",{children:["wiki",{children:["company-wiki",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(t.bind(t,5883)),"/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/company-wiki/page.tsx"]}]},{}]},{metadata:{icon:[async e=>(await Promise.resolve().then(t.bind(t,3881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(t.bind(t,1342)),"/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(t.t.bind(t,9361,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(t.bind(t,3881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],d=["/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/company-wiki/page.tsx"],m="/wiki/company-wiki/page",p={require:t,loadChunk:()=>Promise.resolve()},u=new a.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/wiki/company-wiki/page",pathname:"/wiki/company-wiki",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:l}})},2807:(e,i,t)=>{Promise.resolve().then(t.bind(t,8119))},8119:(e,i,t)=>{"use strict";t.r(i),t.d(i,{default:()=>n});var a=t(2295);t(3729);var r=t(9416);function n(){let e=`
# Company Wiki

## Welcome to Our Company Wiki

This is the central repository for all company-wide information and resources. Here you'll find details about our organization structure, teams, policies, and general company information.

## Company Overview

Our company is dedicated to developing healthcare software solutions with a focus on Electronic Health Records (EHR) and Chronic Care Management (CCM) systems. We are committed to maintaining the highest standards of security, privacy, and compliance in all our operations.

### Mission Statement

To transform healthcare through secure, compliant, and user-friendly software solutions that improve patient outcomes and streamline provider workflows.

### Core Values

- **Patient Privacy First**: We prioritize the protection of patient information above all else
- **Continuous Compliance**: We maintain rigorous standards that exceed regulatory requirements
- **Technical Excellence**: We develop robust, reliable, and scalable solutions
- **Collaborative Innovation**: We work together to solve complex healthcare challenges
- **Ongoing Education**: We commit to continuous learning and knowledge sharing

## Team Structure

Our organization is structured into several key departments:

- **Product Development**
  - Software Engineering
  - Quality Assurance
  - Product Management
  - UX/UI Design

- **Compliance & Security**
  - HIPAA Compliance
  - Security Operations
  - Risk Management
  - Audit & Documentation

- **Customer Success**
  - Implementation
  - Training
  - Support
  - Account Management

- **Business Operations**
  - Finance
  - Human Resources
  - Marketing
  - Legal

## Key Resources

### For New Employees

- [Onboarding Guide](/wiki/company-wiki/onboarding)
- [Company Handbook](/wiki/company-wiki/handbook)
- [IT Setup](/wiki/company-wiki/it-setup)
- [Required Training](/wiki/company-wiki/training)

### Company Policies

- [Code of Conduct](/wiki/company-wiki/policies/code-of-conduct)
- [Remote Work Policy](/wiki/company-wiki/policies/remote-work)
- [Security Policy](/wiki/company-wiki/policies/security)
- [Data Privacy Policy](/wiki/company-wiki/policies/data-privacy)

### Departments and Teams

- [Engineering Team](/wiki/company-wiki/teams/engineering)
- [Compliance Team](/wiki/company-wiki/teams/compliance)
- [Customer Success](/wiki/company-wiki/teams/customer-success)
- [Business Operations](/wiki/company-wiki/teams/business-operations)
`,i=(0,a.jsxs)("div",{className:"prose prose-slate dark:prose-invert max-w-none",children:[(0,a.jsxs)("div",{className:"mb-8",children:[a.jsx("h1",{className:"text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white mb-3",children:"Company Wiki"}),a.jsx("p",{className:"text-xl text-gray-500 dark:text-gray-400",children:"General company information, team structure, and organizational resources"}),a.jsx("div",{className:"text-sm text-gray-500 dark:text-gray-400 mt-2",children:"Last updated: March 13, 2025"}),a.jsx("div",{className:"flex flex-wrap gap-2 mt-4",children:["company","organization","resources"].map(e=>a.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100",children:e},e))})]}),a.jsx("div",{className:"mdx-content",dangerouslySetInnerHTML:{__html:e}})]});return a.jsx(r.q,{children:a.jsx("article",{className:"prose prose-slate dark:prose-invert max-w-none",children:i})})}},9416:(e,i,t)=>{"use strict";t.d(i,{q:()=>s});var a=t(2295);t(3729);var r=t(7385),n=t(3247),o=t(3846);let s=({children:e})=>(0,a.jsxs)("div",{className:"flex h-screen bg-gray-50 dark:bg-gray-950",children:[a.jsx(r.Sidebar,{}),(0,a.jsxs)("div",{className:"flex-1 h-screen flex flex-col overflow-auto",children:[a.jsx("div",{className:"bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800",children:(0,a.jsxs)("div",{className:"flex flex-col md:flex-row md:items-center md:justify-between px-4 py-3",children:[a.jsx(n.Breadcrumb,{}),a.jsx("div",{className:"mt-3 md:mt-0",children:a.jsx(o.SearchBar,{})})]})}),a.jsx("main",{className:"flex-1 overflow-auto p-6",children:a.jsx("div",{className:"max-w-4xl mx-auto",children:e})}),a.jsx("footer",{className:"py-4 px-6 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900",children:(0,a.jsxs)("div",{className:"text-center text-sm text-gray-500 dark:text-gray-400",children:["\xa9 ",new Date().getFullYear().toString()," Company Wiki • HIPAA Compliant"]})})]})]})},5883:(e,i,t)=>{"use strict";t.r(i),t.d(i,{$$typeof:()=>n,__esModule:()=>r,default:()=>o});let a=(0,t(6843).createProxy)(String.raw`/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/company-wiki/page.tsx`),{__esModule:r,$$typeof:n}=a,o=a.default}};var i=require("../../../webpack-runtime.js");i.C(e);var t=e=>i(i.s=e),a=i.X(0,[638,883,754,796],()=>t(444));module.exports=a})();