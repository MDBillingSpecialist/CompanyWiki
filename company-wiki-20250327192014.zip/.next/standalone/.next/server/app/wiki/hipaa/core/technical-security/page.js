(()=>{var e={};e.id=701,e.ids=[701],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1017:e=>{"use strict";e.exports=require("path")},7310:e=>{"use strict";e.exports=require("url")},7974:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>n.a,__next_app__:()=>u,originalPathname:()=>p,pages:()=>d,routeModule:()=>m,tree:()=>l});var i=r(482),a=r(9108),s=r(2563),n=r.n(s),o=r(8300),c={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(c[e]=()=>o[e]);r.d(t,c);let l=["",{children:["wiki",{children:["hipaa",{children:["core",{children:["technical-security",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,2442)),"/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/hipaa/core/technical-security/page.tsx"]}]},{}]},{}]},{}]},{metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,3881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(r.bind(r,1342)),"/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,9361,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,3881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],d=["/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/hipaa/core/technical-security/page.tsx"],p="/wiki/hipaa/core/technical-security/page",u={require:r,loadChunk:()=>Promise.resolve()},m=new i.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/wiki/hipaa/core/technical-security/page",pathname:"/wiki/hipaa/core/technical-security",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:l}})},9932:(e,t,r)=>{Promise.resolve().then(r.bind(r,7249))},7249:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>s});var i=r(2295);r(3729);var a=r(9416);function s(){let e=`
# Technical Security Standards

## 1. Encryption Requirements

### 1.1 Data at Rest
- **[MANDATORY]** All PHI stored in databases must be encrypted using AES-256 encryption.
- **[MANDATORY]** Encryption keys must be stored separately from the encrypted data.
- **[RECOMMENDED]** Implement database column-level encryption for sensitive PHI fields.

### 1.2 Data in Transit
- **[MANDATORY]** All data transmission must use TLS 1.2 or higher.
- **[MANDATORY]** Implement certificate validation to prevent man-in-the-middle attacks.
- **[MANDATORY]** Disable insecure cipher suites.

## 2. Audit Logging

### 2.1 Required Audit Events
- **[MANDATORY]** Log all access to PHI, including read, write, modify, and delete operations.
- **[MANDATORY]** Log all authentication attempts (successful and failed).
- **[MANDATORY]** Log all system and security configuration changes.

### 2.2 Audit Log Content
- **[MANDATORY]** Each log entry must include: timestamp, user ID, action performed, data accessed, and source IP.
- **[MANDATORY]** Audit logs must be tamper-proof and immutable.
- **[RECOMMENDED]** Implement digital signatures for log entries.

## 3. Network Security

- **[MANDATORY]** Implement network segmentation to isolate systems containing PHI.
- **[MANDATORY]** Deploy intrusion detection and prevention systems.
- **[MANDATORY]** Conduct regular vulnerability scans and penetration testing.

## 4. Access Controls

### 4.1 Authentication
- **[MANDATORY]** Implement multi-factor authentication for all administrative access.
- **[MANDATORY]** Enforce strong password policies (complexity, expiration, history).
- **[MANDATORY]** Lock accounts after multiple failed login attempts.

### 4.2 Authorization
- **[MANDATORY]** Implement role-based access control (RBAC).
- **[MANDATORY]** Apply the principle of least privilege.
- **[MANDATORY]** Review access rights quarterly.

## 5. Endpoint Security

- **[MANDATORY]** Implement endpoint protection on all devices accessing PHI.
- **[MANDATORY]** Enforce device encryption for mobile devices.
- **[MANDATORY]** Implement remote wipe capabilities for lost or stolen devices.

## 6. Backup and Recovery

- **[MANDATORY]** Perform regular backups of all systems containing PHI.
- **[MANDATORY]** Encrypt all backups.
- **[MANDATORY]** Test backup restoration quarterly.
- **[MANDATORY]** Store backups in a secure, offsite location.

## 7. Security Monitoring

- **[MANDATORY]** Implement 24/7 security monitoring.
- **[MANDATORY]** Deploy security information and event management (SIEM) solutions.
- **[MANDATORY]** Establish incident detection and response procedures.

## 8. Vulnerability Management

- **[MANDATORY]** Perform regular vulnerability assessments.
- **[MANDATORY]** Implement a patch management process.
- **[MANDATORY]** Conduct annual penetration testing.

## 9. Application Security

- **[MANDATORY]** Follow secure coding practices.
- **[MANDATORY]** Perform security code reviews.
- **[MANDATORY]** Conduct security testing before production deployment.

## 10. Compliance Verification

- **[MANDATORY]** Conduct regular security risk assessments.
- **[MANDATORY]** Perform annual HIPAA compliance audits.
- **[MANDATORY]** Document all security measures and controls.

## Implementation Guidelines

For implementation details and technical specifications, refer to the following resources:

- [NIST Special Publication 800-66](https://csrc.nist.gov/publications/detail/sp/800-66/rev-1/final) - An Introductory Resource Guide for Implementing the HIPAA Security Rule
- [HHS Guidance on Risk Analysis](https://www.hhs.gov/hipaa/for-professionals/security/guidance/guidance-risk-analysis/index.html)
- [OCR Audit Protocol](https://www.hhs.gov/hipaa/for-professionals/compliance-enforcement/audit/protocol/index.html)

## Contact

For questions or clarification on technical security standards, contact the Security Officer at security@example.com.
`,t=(0,i.jsxs)("div",{className:"prose prose-slate dark:prose-invert max-w-none",children:[(0,i.jsxs)("div",{className:"mb-8",children:[i.jsx("h1",{className:"text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white mb-3",children:"Technical Security Standards"}),i.jsx("p",{className:"text-xl text-gray-500 dark:text-gray-400",children:"HIPAA technical security requirements for healthcare software"}),i.jsx("div",{className:"text-sm text-gray-500 dark:text-gray-400 mt-2",children:"Last updated: March 13, 2025"}),i.jsx("div",{className:"flex flex-wrap gap-2 mt-4",children:["hipaa","security","encryption","audit"].map(e=>i.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100",children:e},e))})]}),i.jsx("div",{className:"mdx-content",dangerouslySetInnerHTML:{__html:e}})]});return i.jsx(a.q,{children:i.jsx("article",{className:"prose prose-slate dark:prose-invert max-w-none",children:t})})}},9416:(e,t,r)=>{"use strict";r.d(t,{q:()=>o});var i=r(2295);r(3729);var a=r(7385),s=r(3247),n=r(3846);let o=({children:e})=>(0,i.jsxs)("div",{className:"flex h-screen bg-gray-50 dark:bg-gray-950",children:[i.jsx(a.Sidebar,{}),(0,i.jsxs)("div",{className:"flex-1 h-screen flex flex-col overflow-auto",children:[i.jsx("div",{className:"bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800",children:(0,i.jsxs)("div",{className:"flex flex-col md:flex-row md:items-center md:justify-between px-4 py-3",children:[i.jsx(s.Breadcrumb,{}),i.jsx("div",{className:"mt-3 md:mt-0",children:i.jsx(n.SearchBar,{})})]})}),i.jsx("main",{className:"flex-1 overflow-auto p-6",children:i.jsx("div",{className:"max-w-4xl mx-auto",children:e})}),i.jsx("footer",{className:"py-4 px-6 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900",children:(0,i.jsxs)("div",{className:"text-center text-sm text-gray-500 dark:text-gray-400",children:["\xa9 ",new Date().getFullYear().toString()," Company Wiki • HIPAA Compliant"]})})]})]})},2442:(e,t,r)=>{"use strict";r.r(t),r.d(t,{$$typeof:()=>s,__esModule:()=>a,default:()=>n});let i=(0,r(6843).createProxy)(String.raw`/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/hipaa/core/technical-security/page.tsx`),{__esModule:a,$$typeof:s}=i,n=i.default}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[638,883,754,796],()=>r(7974));module.exports=i})();