(()=>{var e={};e.id=506,e.ids=[506],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1017:e=>{"use strict";e.exports=require("path")},7310:e=>{"use strict";e.exports=require("url")},6613:(e,t,i)=>{"use strict";i.r(t),i.d(t,{GlobalError:()=>n.a,__next_app__:()=>m,originalPathname:()=>p,pages:()=>d,routeModule:()=>u,tree:()=>c});var a=i(482),r=i(9108),s=i(2563),n=i.n(s),o=i(8300),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);i.d(t,l);let c=["",{children:["wiki",{children:["hipaa",{children:["llm-compliance",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(i.bind(i,8659)),"/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/hipaa/llm-compliance/page.tsx"]}]},{}]},{}]},{metadata:{icon:[async e=>(await Promise.resolve().then(i.bind(i,3881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(i.bind(i,1342)),"/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(i.t.bind(i,9361,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(i.bind(i,3881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],d=["/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/hipaa/llm-compliance/page.tsx"],p="/wiki/hipaa/llm-compliance/page",m={require:i,loadChunk:()=>Promise.resolve()},u=new a.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/wiki/hipaa/llm-compliance/page",pathname:"/wiki/hipaa/llm-compliance",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},2397:(e,t,i)=>{Promise.resolve().then(i.bind(i,8514))},8514:(e,t,i)=>{"use strict";i.r(t),i.d(t,{default:()=>s});var a=i(2295);i(3729);var r=i(9416);function s(){let e=`
# HIPAA Compliance for LLMs in Healthcare

## Overview

Large Language Models (LLMs) offer powerful capabilities for healthcare applications, but their use must comply with HIPAA regulations to protect patient privacy and security. This document provides comprehensive guidance on implementing LLMs in healthcare settings while maintaining HIPAA compliance.

## Regulatory Compliance & Legal Requirements

### HIPAA Rules Applicable to LLMs

When implementing LLMs in healthcare, you must comply with all relevant HIPAA regulations:

- **Privacy Rule**: Governs how Protected Health Information (PHI) can be used or disclosed
- **Security Rule**: Mandates safeguards to protect electronic PHI (ePHI)
- **Breach Notification Rule**: Requires notifying affected parties if PHI is compromised
- **HITECH Act**: Strengthened HIPAA enforcement and introduced incentives/penalties related to PHI security

### HIPAA Privacy Rule (Use/Disclosure of PHI)

Before using PHI with an LLM, determine if the use is permitted under HIPAA's Privacy Rule:

- PHI use is generally allowed without patient authorization only for Treatment, Payment, or Healthcare Operations (TPO), or certain public interest exceptions
- Using PHI to directly care for patients (treatment) or for care coordination and quality improvement (operations) can be permissible without additional consent
- If PHI will be used to train or develop an AI model, it may not fall under TPO and could be considered a secondary use (or "research")
- In such cases, patient authorization (consent) is usually required unless the data is fully de-identified

### Business Associate Agreements (BAAs)

Determine if your LLM or its provider is a Business Associate under HIPAA:

- A Business Associate is any person or entity that "creates, receives, maintains, or transmits" PHI on behalf of a covered entity
- If you are using a third-party LLM service or API that involves PHI, that service qualifies as a Business Associate
- Cloud service providers hosting ePHI – even if only storing encrypted PHI and lacking the decryption key – are considered Business Associates
- Before integrating any external LLM, execute a HIPAA-compliant BAA with the vendor
- If a vendor will not sign a BAA, do not use real PHI with that service

## PHI Handling and Data Anonymization

### De-identify PHI Whenever Possible

The best way to protect patient privacy when using LLMs is to remove identifying information:

- De-identified data is not subject to HIPAA regulations
- HIPAA provides two accepted methods for de-identification:
  1. **Safe Harbor method**: Remove 18 types of identifiers and any other information that could identify the individual or their relatives/household
  2. **Expert Determination method**: A qualified expert uses statistical methods to conclude that the risk of re-identifying individuals is very small

### Approved Anonymization Techniques

Follow HHS guidance for de-identification:

- **Removal or Masking of Identifiers**: Strip out personal data like names, phone numbers, emails, medical record numbers, device identifiers, biometric identifiers, photographs, etc.
- **Aggregation and Generalization**: Use ranges or categories instead of specific values
- **Data Masking/Pseudonymization**: Mask data fields needed for context so that the model still gets structured input without real PHI
- **Expert Statistical De-identification**: Apply k-anonymity, l-diversity, differential privacy, or other techniques to ensure that combinations of health data cannot single out a person
`,t=(0,a.jsxs)("div",{className:"prose prose-slate dark:prose-invert max-w-none",children:[(0,a.jsxs)("div",{className:"mb-8",children:[a.jsx("h1",{className:"text-3xl font-extrabold tracking-tight text-gray-900 dark:text-white mb-3",children:"HIPAA Compliance for LLMs in Healthcare"}),a.jsx("p",{className:"text-xl text-gray-500 dark:text-gray-400",children:"Guidelines for implementing Large Language Models in healthcare while maintaining HIPAA compliance"}),a.jsx("div",{className:"text-sm text-gray-500 dark:text-gray-400 mt-2",children:"Last updated: March 13, 2025"}),a.jsx("div",{className:"flex flex-wrap gap-2 mt-4",children:["hipaa","compliance","ai","llm","healthcare"].map(e=>a.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100",children:e},e))})]}),a.jsx("div",{className:"mdx-content",dangerouslySetInnerHTML:{__html:e}})]});return a.jsx(r.q,{children:a.jsx("article",{className:"prose prose-slate dark:prose-invert max-w-none",children:t})})}},9416:(e,t,i)=>{"use strict";i.d(t,{q:()=>o});var a=i(2295);i(3729);var r=i(7385),s=i(3247),n=i(3846);let o=({children:e})=>(0,a.jsxs)("div",{className:"flex h-screen bg-gray-50 dark:bg-gray-950",children:[a.jsx(r.Sidebar,{}),(0,a.jsxs)("div",{className:"flex-1 h-screen flex flex-col overflow-auto",children:[a.jsx("div",{className:"bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800",children:(0,a.jsxs)("div",{className:"flex flex-col md:flex-row md:items-center md:justify-between px-4 py-3",children:[a.jsx(s.Breadcrumb,{}),a.jsx("div",{className:"mt-3 md:mt-0",children:a.jsx(n.SearchBar,{})})]})}),a.jsx("main",{className:"flex-1 overflow-auto p-6",children:a.jsx("div",{className:"max-w-4xl mx-auto",children:e})}),a.jsx("footer",{className:"py-4 px-6 border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900",children:(0,a.jsxs)("div",{className:"text-center text-sm text-gray-500 dark:text-gray-400",children:["\xa9 ",new Date().getFullYear().toString()," Company Wiki • HIPAA Compliant"]})})]})]})},8659:(e,t,i)=>{"use strict";i.r(t),i.d(t,{$$typeof:()=>s,__esModule:()=>r,default:()=>n});let a=(0,i(6843).createProxy)(String.raw`/Users/WoundCentrics/Desktop/Code Projects/Work Projects/Company Wiki/company-wiki/src/app/wiki/hipaa/llm-compliance/page.tsx`),{__esModule:r,$$typeof:s}=a,n=a.default}};var t=require("../../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),a=t.X(0,[638,883,754,796],()=>i(6613));module.exports=a})();